module Puppet::Parser::Functions
  newfunction(:brent_k, :type => :rvalue) do |args|
    val = 'ok'
    val
  end
end
